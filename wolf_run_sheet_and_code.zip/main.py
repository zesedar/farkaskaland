from pathlib import Path

import pygame


# --- Game setup ---
WIDTH, HEIGHT = 960, 540
FPS = 60
GROUND_Y = 430

PLAYER_SPEED = 280
JUMP_POWER = 720
GRAVITY = 1900
SPRITE_HEIGHT = 120

# Futás sprite sheet:
# 4 oszlop x 3 sor, minden képkocka pontosan 256x256 px.
RUN_SHEET_COLUMNS = 4
RUN_SHEET_ROWS = 3
RUN_FRAME_WIDTH = 256
RUN_FRAME_HEIGHT = 256


def load_sprite(path: Path, target_height: int = SPRITE_HEIGHT) -> pygame.Surface:
    """Load a PNG with alpha and scale it to a consistent height."""
    image = pygame.image.load(str(path)).convert_alpha()
    scale = target_height / image.get_height()
    new_size = (int(image.get_width() * scale), target_height)
    return pygame.transform.scale(image, new_size)


def load_animation_frames(asset_dir: Path, prefix: str) -> list[pygame.Surface]:
    """Load old-style separate animation frame files, used by idle and jump."""
    files = sorted(
        asset_dir.glob(f"{prefix}_*.png"),
        key=lambda p: int(p.stem.split("_")[-1]),
    )
    if not files:
        raise FileNotFoundError(f"No animation frames found for {prefix} in {asset_dir}")
    return [load_sprite(path) for path in files]


def load_sprite_sheet(
    path: Path,
    frame_width: int,
    frame_height: int,
    columns: int,
    rows: int,
    target_height: int = SPRITE_HEIGHT,
) -> list[pygame.Surface]:
    """
    Egyetlen sprite sheetből vágja ki a frame-eket futás közben.

    Sorrend:
    0  1  2  3
    4  5  6  7
    8  9 10 11
    """
    sheet = pygame.image.load(str(path)).convert_alpha()

    expected_width = frame_width * columns
    expected_height = frame_height * rows
    if sheet.get_width() != expected_width or sheet.get_height() != expected_height:
        raise ValueError(
            f"A sprite sheet mérete hibás: {sheet.get_width()}x{sheet.get_height()} px. "
            f"Elvárt méret: {expected_width}x{expected_height} px."
        )

    frames: list[pygame.Surface] = []
    for row in range(rows):
        for col in range(columns):
            x = col * frame_width
            y = row * frame_height

            frame = sheet.subsurface(
                pygame.Rect(x, y, frame_width, frame_height)
            ).copy()

            scale = target_height / frame.get_height()
            new_size = (
                int(frame.get_width() * scale),
                target_height,
            )
            frame = pygame.transform.scale(frame, new_size)
            frames.append(frame)

    return frames


def draw_static_background(screen: pygame.Surface) -> None:
    """A simple original retro-platformer playground background."""
    # Sky
    screen.fill((136, 207, 255))

    # Sun
    pygame.draw.circle(screen, (255, 234, 128), (820, 80), 38)

    # Clouds
    for x, y in [(120, 85), (420, 70), (680, 125)]:
        pygame.draw.circle(screen, (255, 255, 255), (x, y), 26)
        pygame.draw.circle(screen, (255, 255, 255), (x + 30, y - 8), 32)
        pygame.draw.circle(screen, (255, 255, 255), (x + 65, y), 24)
        pygame.draw.rect(screen, (255, 255, 255), (x, y, 65, 25), border_radius=12)

    # Distant hills
    pygame.draw.circle(screen, (99, 198, 119), (210, 430), 170)
    pygame.draw.circle(screen, (75, 176, 105), (550, 450), 210)
    pygame.draw.circle(screen, (110, 210, 125), (880, 430), 160)

    # Ground
    pygame.draw.rect(screen, (93, 191, 80), (0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y))
    pygame.draw.rect(screen, (67, 151, 65), (0, GROUND_Y + 18, WIDTH, HEIGHT - GROUND_Y - 18))

    # Simple tile pattern
    tile = 48
    for x in range(0, WIDTH, tile):
        pygame.draw.line(screen, (53, 130, 55), (x, GROUND_Y + 18), (x, HEIGHT), 2)
    for y in range(GROUND_Y + 18, HEIGHT, tile):
        pygame.draw.line(screen, (53, 130, 55), (0, y), (WIDTH, y), 2)

    # A few blocks/platform decorations
    for rect in [(120, 330, 120, 32), (640, 300, 150, 32)]:
        pygame.draw.rect(screen, (217, 151, 78), rect, border_radius=4)
        pygame.draw.rect(screen, (130, 87, 49), rect, 3, border_radius=4)


class Player:
    def __init__(self) -> None:
        asset_dir = Path(__file__).parent / "assets"

        # Állás és ugrás: külön PNG frame-ek.
        self.idle_frames = load_animation_frames(asset_dir, "idle")
        self.jump_frames = load_animation_frames(asset_dir, "jump")

        # Futás: EGYETLEN sprite sheetből dolgozik.
        # Nem használ run_0.png, run_1.png stb. fájlokat.
        self.run_frames = load_sprite_sheet(
            asset_dir / "wolf_run_sheet.png",
            frame_width=RUN_FRAME_WIDTH,
            frame_height=RUN_FRAME_HEIGHT,
            columns=RUN_SHEET_COLUMNS,
            rows=RUN_SHEET_ROWS,
        )

        self.x = 180.0
        self.y = float(GROUND_Y)
        self.vx = 0.0
        self.vy = 0.0
        self.facing_right = True
        self.on_ground = True

        self.idle_timer = 0.0
        self.run_timer = 0.0

    def handle_input(self, dt: float) -> None:
        keys = pygame.key.get_pressed()

        moving_left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        moving_right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        wants_jump = keys[pygame.K_SPACE] or keys[pygame.K_UP] or keys[pygame.K_w]

        self.vx = 0.0
        if moving_left:
            self.vx -= PLAYER_SPEED
            self.facing_right = False
        if moving_right:
            self.vx += PLAYER_SPEED
            self.facing_right = True

        self.x += self.vx * dt
        self.x = max(55, min(WIDTH - 55, self.x))

        if wants_jump and self.on_ground:
            self.vy = -JUMP_POWER
            self.on_ground = False

    def update_physics(self, dt: float) -> None:
        if not self.on_ground:
            self.vy += GRAVITY * dt
            self.y += self.vy * dt

            if self.y >= GROUND_Y:
                self.y = float(GROUND_Y)
                self.vy = 0.0
                self.on_ground = True

        moving = abs(self.vx) > 1
        if self.on_ground and moving:
            self.run_timer += dt
            self.idle_timer = 0.0
        elif self.on_ground:
            self.idle_timer += dt
            self.run_timer = 0.0

    def current_image(self) -> pygame.Surface:
        moving = abs(self.vx) > 1

        if not self.on_ground:
            # Pick jump frame by motion phase.
            if self.vy < -260:
                index = 0
            elif self.vy < -40:
                index = min(1, len(self.jump_frames) - 1)
            elif self.vy < 240:
                index = min(2, len(self.jump_frames) - 1)
            else:
                index = len(self.jump_frames) - 1

            image = self.jump_frames[index]

        elif moving:
            # 12 képkockás futás. Minél kisebb ez a szám, annál gyorsabb az animáció.
            frame_index = int(self.run_timer / 0.07) % len(self.run_frames)
            image = self.run_frames[frame_index]

        else:
            frame_index = int(self.idle_timer / 0.22) % len(self.idle_frames)
            image = self.idle_frames[frame_index]

        if not self.facing_right:
            image = pygame.transform.flip(image, True, False)

        return image

    def draw(self, screen: pygame.Surface) -> None:
        # Shadow gets smaller while jumping.
        height_above_ground = max(0, GROUND_Y - self.y)
        shadow_width = max(30, int(96 - height_above_ground * 0.10))
        shadow_height = max(8, int(18 - height_above_ground * 0.02))
        shadow_rect = pygame.Rect(0, 0, shadow_width, shadow_height)
        shadow_rect.center = (int(self.x), GROUND_Y + 7)
        pygame.draw.ellipse(screen, (62, 92, 65), shadow_rect)

        image = self.current_image()
        rect = image.get_rect(midbottom=(int(self.x), int(self.y)))
        screen.blit(image, rect)


def main() -> None:
    pygame.init()
    pygame.display.set_caption("Little Wolf Playground")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    player = Player()

    font = pygame.font.SysFont(None, 26)

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        player.handle_input(dt)
        player.update_physics(dt)

        draw_static_background(screen)
        player.draw(screen)

        help_text = font.render("Move: A/D or ←/→    Jump: W/↑/Space    Quit: close window", True, (30, 40, 45))
        screen.blit(help_text, (22, 18))

        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
